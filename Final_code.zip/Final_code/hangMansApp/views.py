import random

from django.contrib.sites.shortcuts import get_current_site
from django.http import JsonResponse
from django.shortcuts import render
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from .forms import UserRegisterForm

from django.contrib import messages
from django.contrib.auth.decorators import login_required

from .models import Word,Hint
from hangMansApp import models


def Start(request):
    forRandomId = [] 
    forHint = []
    for r in models.Word.objects.all():
        forRandomId.append(r.id)
    for h in models.Word.objects.all():
        forHint.append(h.id)
    
    
    wordId = random.randint(1,len(forRandomId))
    
    wordIdFriend = random.choice(forRandomId)
    word = models.Word.objects.get(id=wordId)
    hints = models.Word.objects.values_list('hint',flat=True).get(id=wordId)
    wordArray = []
    for n in range(len(word.word)):
        wordArray.append("")
    domain = get_current_site(request)
    return render(request, 'index.html', {'wordId': wordId, "word": wordArray, "fault": 1,
                                          'wordForFriend': models.Word.objects.get(id=wordIdFriend),
                                          'domain': domain, 'hints': hints})

def updateWord(request):
    wordArray = []
    if request.method == 'GET':
        wordId = request.GET.get('wordId')
        fault = request.GET.get('faults')
        letter = request.GET.get('letter')
        gameId = request.GET.get('gameId')
        word = models.Word.objects.get(id=wordId)
        session = ''
        try:
            session = str(request.COOKIES['csrftoken'])
        except:
            pass
        if session != '':
            try:
                session = str(request.META['CSRF_COOKIE'])
            except:
                pass
        game = models.Game.objects.filter(session=session, id=int(gameId))
        if game.count() == 0:
            game = models.Game.objects.create(session=session, word_id=wordId)
        else:
            game = game.first()
            if game.fault >= 6:
                return JsonResponse({'lose': True})
        if letter in word.word:
            game.letterKnows = game.letterKnows + letter
            for v in word.word:
                if v in game.letterKnows:
                    wordArray.append(v)
                else:
                    wordArray.append("")
            if list(word.word) == wordArray:
                game.win = True
                game.save()
                return JsonResponse({'win': True, 'wordArray': wordArray})
            game.save()
            return JsonResponse({'gameId': game.id, 'fault': 0, 'wordArray': wordArray, 'win': False, 'letter': letter})
        else:
            game.fault = game.fault + 1
            game.save()
            if game.fault >= 6:
                return JsonResponse({'lose': True, 'word': word.word.upper()})
            return JsonResponse({'gameId': game.id, 'fault': game.fault + 1, 'win': False, 'letter': letter})

def playShare(request, uui):
    print(uui)
    forRandomId = []
    for r in models.Word.objects.all():
        forRandomId.append(r.id)
    wordIdFriend = random.choice(forRandomId)
    word = models.Word.objects.get(uui=uui)
    wordArray = []
    for n in range(len(word.word)):
        wordArray.append("")
    domain = get_current_site(request)
    return render(request, 'index.html', {'wordId': word.id, "word": wordArray, "fault": 1,
                                          'wordForFriend': models.Word.objects.get(id=wordIdFriend),
                                          'domain': domain})

def generateWord(request):
    forRandomId = []
    for r in models.Word.objects.all():
        forRandomId.append(r.id)
    wordIdFriend = random.choice(forRandomId)
    word = models.Word.objects.get(id=wordIdFriend)
    domain = get_current_site(request)
    return JsonResponse({"word": word.word, "domain": str(domain), 'uuid': str(word.uui)})

# def chargeDB():
#     fich = open("static/Hangman_wordbank.txt")
#     line = fich.readlines()
#     array = line[0].split(', ')
#     print(array)
#     for a in array:
#         word = a.replace(" ", "").replace("\n", "")
#         exist = models.Word.objects.filter(word=word)
#         if exist.count() == 0:
#             models.Word.objects.create(word=word)
#     for w in models.Word.objects.all():
#         print(w.word)


def home(request):
    return render(request, 'index.html')


def register(request):
    if request.method == "POST":
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Hi {username}, your account was created successfully,now you can login.')
            return redirect('home')
    else:
        form = UserRegisterForm()

    return render(request, 'users/register.html', {'form': form})


@login_required()
def profile(request):
    return render(request, 'users/profile.html')





















