import json
o=open("word.json",'r')
print(o)